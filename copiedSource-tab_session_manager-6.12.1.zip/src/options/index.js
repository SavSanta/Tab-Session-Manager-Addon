import React from "react";
import ReactDOM from "react-dom";
import OptionsPage from "./components/OptionsPage";

ReactDOM.render(<OptionsPage />, document.getElementById("root"));
